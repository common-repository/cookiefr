# Cookiefr

Cookiefr version 0.1 permet de gérer à votre place la gestion du message légal sur les cookies.

![message](msg.png)    

## Autheur
 
Kévin FERRANDON
mailto: kferrandon[a]gmail.com
      

